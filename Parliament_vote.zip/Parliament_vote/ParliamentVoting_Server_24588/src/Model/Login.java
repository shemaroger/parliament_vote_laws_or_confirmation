
package Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class Login implements Serializable{
   @Id
//   @GeneratedValue(strategy = GenerationType.IDENTITY)
//   @Column(name = "login_id")
   private Integer id;
//   private String name;
//   private String email;
//   private String password;
//   private String role;
//   @OneToMany
//   @JoinColumn(name="")
}
